import { GoogleGenAI, Type } from "@google/genai";
import { MENU_ITEMS, MenuItem } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function getMealRecommendation(context: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Based on the following context: "${context}", recommend a meal from our menu. 
    Menu: ${JSON.stringify(MENU_ITEMS.map(i => ({ name: i.name, description: i.description })))}
    Provide a catchy, appetite-triggering recommendation in 2 sentences.`,
  });
  return response.text || "How about a Big Mac? It's a classic!";
}

export async function smartSearch(query: string): Promise<MenuItem[]> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `The user is searching for: "${query}". 
    Based on our menu: ${JSON.stringify(MENU_ITEMS.map(i => ({ id: i.id, name: i.name, price: i.price, description: i.description })))}
    Return a JSON array of item IDs that match the search criteria. 
    If they ask for "under $5", return items with price < 5.
    If they ask for "chicken", return chicken items.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: { type: Type.STRING }
      }
    }
  });

  try {
    const ids = JSON.parse(response.text || "[]") as string[];
    return MENU_ITEMS.filter(item => ids.includes(item.id));
  } catch (e) {
    console.error("Failed to parse AI search results", e);
    return [];
  }
}

export async function chatAssistant(message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]): Promise<string> {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: `You are a helpful and friendly McDonald's virtual assistant. 
      You help users find items on the menu, explain ingredients, and provide recommendations.
      Keep your tone upbeat, professional, and brand-aligned.
      Menu: ${JSON.stringify(MENU_ITEMS)}`,
    },
  });

  // Reconstruct history if needed, but for simplicity we'll just send the message
  // In a real app, we'd pass the full history to ai.chats.create
  const response = await chat.sendMessage({ message });
  return response.text || "I'm here to help! What can I get for you today?";
}
