/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import MenuPage from './components/Menu';
import DealsPage from './components/Deals';
import ChatAssistant from './components/ChatAssistant';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-dark selection:bg-gold selection:text-dark">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/menu" element={<MenuPage />} />
            <Route path="/deals" element={<DealsPage />} />
            <Route path="/locations" element={<div className="pt-32 px-6 text-center">Locations Page Coming Soon</div>} />
            <Route path="/loyalty" element={<div className="pt-32 px-6 text-center">Loyalty Page Coming Soon</div>} />
            <Route path="/order" element={<div className="pt-32 px-6 text-center">Order Flow Coming Soon</div>} />
          </Routes>
        </main>
        
        <ChatAssistant />
        
        <footer className="border-t border-border mt-20 py-12 px-6">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="font-display text-3xl text-gold tracking-widest">MCDONALD'S</div>
            <div className="flex gap-8 text-sm text-muted">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Accessibility</a>
            </div>
            <p className="text-xs text-muted">© 2026 McDonald's. All Rights Reserved.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}

