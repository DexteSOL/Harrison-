export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'Burgers' | 'Chicken' | 'Breakfast' | 'Drinks' | 'Desserts' | 'Fries';
  image: string;
  calories: number;
  popular?: boolean;
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'big-mac',
    name: 'Big Mac',
    description: 'Two 100% beef patties, a slice of cheese, lettuce, onion and pickles and the unbeatable Big Mac sauce.',
    price: 5.99,
    category: 'Burgers',
    image: 'https://picsum.photos/seed/bigmac/400/300',
    calories: 550,
    popular: true
  },
  {
    id: 'quarter-pounder',
    name: 'Quarter Pounder with Cheese',
    description: 'A quarter pound of 100% fresh beef that’s sizzled on our flat iron grill.',
    price: 6.49,
    category: 'Burgers',
    image: 'https://picsum.photos/seed/qpc/400/300',
    calories: 520
  },
  {
    id: 'mcchicken',
    name: 'McChicken',
    description: 'Crispy chicken patty topped with mayonnaise and shredded lettuce.',
    price: 4.29,
    category: 'Chicken',
    image: 'https://picsum.photos/seed/mcchicken/400/300',
    calories: 400
  },
  {
    id: 'nuggets-10',
    name: '10pc Chicken McNuggets',
    description: 'Tender, juicy Chicken McNuggets made with 100% white meat chicken.',
    price: 7.99,
    category: 'Chicken',
    image: 'https://picsum.photos/seed/nuggets/400/300',
    calories: 420,
    popular: true
  },
  {
    id: 'large-fries',
    name: 'World Famous Fries',
    description: 'Our World Famous Fries are made with premium potatoes such as the Russet Burbank and the Shepody.',
    price: 3.49,
    category: 'Fries',
    image: 'https://picsum.photos/seed/fries/400/300',
    calories: 480,
    popular: true
  },
  {
    id: 'egg-mcmuffin',
    name: 'Egg McMuffin',
    description: 'A freshly cracked Grade A egg on a toasted English Muffin topped with real butter and lean Canadian bacon.',
    price: 4.59,
    category: 'Breakfast',
    image: 'https://picsum.photos/seed/mcmuffin/400/300',
    calories: 310
  },
  {
    id: 'coca-cola',
    name: 'Coca-Cola',
    description: 'Enjoy a cold, refreshing Coca-Cola with your meal.',
    price: 1.99,
    category: 'Drinks',
    image: 'https://picsum.photos/seed/coke/400/300',
    calories: 200
  },
  {
    id: 'mcflurry',
    name: 'Oreo McFlurry',
    description: 'Creamy vanilla soft serve with pieces of OREO cookies.',
    price: 3.99,
    category: 'Desserts',
    image: 'https://picsum.photos/seed/mcflurry/400/300',
    calories: 510,
    popular: true
  }
];
