import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Star, Clock, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getMealRecommendation } from '../services/geminiService';

export default function Home() {
  const [recommendation, setRecommendation] = useState<string>("");
  const [loadingRec, setLoadingRec] = useState(false);

  useEffect(() => {
    async function fetchRec() {
      setLoadingRec(true);
      try {
        const hour = new Date().getHours();
        let context = "lunch time";
        if (hour < 11) context = "breakfast time";
        if (hour > 18) context = "dinner time";
        
        const rec = await getMealRecommendation(context);
        setRecommendation(rec);
      } catch (e) {
        console.error(e);
      } finally {
        setLoadingRec(false);
      }
    }
    fetchRec();
  }, []);

  return (
    <div className="relative min-h-screen pt-24 overflow-hidden">
      {/* Background Arch */}
      <div className="absolute -right-20 top-1/2 -translate-y-1/2 font-display text-[600px] text-gold/5 leading-none select-none pointer-events-none tracking-tighter">
        M
      </div>

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 bg-gold/10 border border-gold/30 rounded-full px-4 py-1.5 mb-8">
            <div className="w-1.5 h-1.5 rounded-full bg-gold animate-pulse" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-gold">Build Specification — 2026</span>
          </div>

          <h1 className="font-display text-7xl sm:text-8xl md:text-9xl leading-[0.9] mb-6">
            MC<span className="text-gold">DONALD'S</span><br />
            <span className="text-mcd-red">HIGH-CONVERT</span><br />
            EXPERIENCE
          </h1>

          <p className="text-muted text-lg max-w-lg mb-10 leading-relaxed">
            A full-stack, AI-powered web presence built with Google AI Studio and Gemini — engineered to drive orders, loyalty, and brand love at scale.
          </p>

          <div className="flex flex-wrap gap-4 mb-12">
            <Link to="/menu" className="bg-gold text-dark px-8 py-4 rounded-xl font-bold flex items-center gap-2 hover:scale-105 transition-transform active:scale-95">
              View Menu
              <ArrowRight size={20} />
            </Link>
            <Link to="/loyalty" className="glass-card px-8 py-4 font-bold hover:bg-white/5 transition-colors">
              Join Rewards
            </Link>
          </div>

          <div className="grid grid-cols-3 gap-8 pt-10 border-t border-border">
            <div className="space-y-1">
              <div className="font-display text-4xl text-gold">12</div>
              <div className="text-[10px] uppercase tracking-widest text-muted">Core Pages</div>
            </div>
            <div className="space-y-1">
              <div className="font-display text-4xl text-gold">8</div>
              <div className="text-[10px] uppercase tracking-widest text-muted">AI Features</div>
            </div>
            <div className="space-y-1">
              <div className="font-display text-4xl text-gold">24/7</div>
              <div className="text-[10px] uppercase tracking-widest text-muted">Ordering</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="relative z-10 aspect-square rounded-3xl overflow-hidden glass-card p-1">
            <img 
              src="https://picsum.photos/seed/mcd-hero/800/800" 
              alt="Delicious McDonald's Meal" 
              className="w-full h-full object-cover rounded-[22px]"
              referrerPolicy="no-referrer"
            />
            
            {/* AI Recommendation Overlay */}
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1 }}
              className="absolute bottom-6 left-6 right-6 glass-card p-6 shadow-2xl"
            >
              <div className="flex items-center gap-2 mb-2">
                <Zap size={16} className="text-gold fill-gold" />
                <span className="text-[10px] font-mono uppercase tracking-widest text-gold">AI Recommendation</span>
              </div>
              <p className="text-sm font-medium leading-relaxed">
                {loadingRec ? "Thinking of the perfect meal for you..." : recommendation}
              </p>
            </motion.div>
          </div>

          {/* Floating Badges */}
          <div className="absolute -top-6 -right-6 glass-card p-4 shadow-xl animate-bounce-slow">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-mcd-red rounded-full flex items-center justify-center">
                <Star size={20} className="text-white fill-white" />
              </div>
              <div>
                <div className="text-xs font-bold">Daily Deal</div>
                <div className="text-[10px] text-muted">50% Off Big Mac</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
