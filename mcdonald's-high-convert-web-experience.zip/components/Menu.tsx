import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Filter, Plus, Info, Zap } from 'lucide-react';
import { MENU_ITEMS, MenuItem } from '../constants';
import { cn } from '../lib/utils';
import { smartSearch } from '../services/geminiService';

export default function MenuPage() {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MenuItem[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  const categories = ['All', 'Burgers', 'Chicken', 'Breakfast', 'Drinks', 'Desserts', 'Fries'];

  const filteredItems = searchResults || (activeCategory === 'All' 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === activeCategory));

  const handleSmartSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setSearchResults(null);
      return;
    }
    setIsSearching(true);
    try {
      const results = await smartSearch(searchQuery);
      setSearchResults(results);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-12">
          <div>
            <h1 className="font-display text-6xl mb-4 uppercase tracking-tight">Our Menu</h1>
            <p className="text-muted max-w-md">Explore our world-famous menu, from the classic Big Mac to our refreshing McCafé drinks.</p>
          </div>

          <form onSubmit={handleSmartSearch} className="relative w-full md:w-96">
            <input 
              type="text" 
              placeholder="Try 'under $5' or 'spicy chicken'..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-card border border-border rounded-xl py-4 pl-12 pr-4 focus:outline-none focus:border-gold transition-colors"
            />
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={20} />
            <button 
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-gold text-dark p-2 rounded-lg hover:scale-105 transition-transform"
            >
              <Zap size={16} className="fill-dark" />
            </button>
          </form>
        </div>

        {/* Categories */}
        <div className="flex overflow-x-auto gap-3 pb-8 no-scrollbar">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => {
                setActiveCategory(cat);
                setSearchResults(null);
                setSearchQuery('');
              }}
              className={cn(
                "px-6 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all border",
                activeCategory === cat 
                  ? "bg-gold border-gold text-dark" 
                  : "bg-card border-border text-muted hover:border-gold/50"
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        {isSearching ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-12 h-12 border-4 border-gold border-t-transparent rounded-full animate-spin" />
            <p className="text-muted font-mono text-xs uppercase tracking-widest">AI is searching the menu...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="glass-card group overflow-hidden"
              >
                <div className="aspect-[4/3] overflow-hidden relative">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {item.popular && (
                    <div className="absolute top-4 left-4 bg-gold text-dark text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
                      Popular
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-lg">{item.name}</h3>
                    <span className="font-mono text-gold">${item.price}</span>
                  </div>
                  <p className="text-muted text-sm line-clamp-2 mb-6 leading-relaxed">
                    {item.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-[10px] text-muted font-mono uppercase">
                      <Info size={12} />
                      {item.calories} kcal
                    </div>
                    <button className="bg-white/5 hover:bg-gold hover:text-dark p-2 rounded-lg transition-all">
                      <Plus size={20} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {filteredItems.length === 0 && !isSearching && (
          <div className="text-center py-20">
            <p className="text-muted">No items found matching your search.</p>
          </div>
        )}
      </div>
    </div>
  );
}
