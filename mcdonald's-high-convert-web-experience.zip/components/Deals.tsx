import React from 'react';
import { motion } from 'motion/react';
import { Tag, Clock, ArrowRight, Gift } from 'lucide-react';

const DEALS = [
  {
    id: 'deal-1',
    title: '50% Off Big Mac',
    description: 'Get your favorite burger at half price. Today only!',
    code: 'BIGMAC50',
    expiry: 'Ends in 4h 20m',
    color: 'bg-gold'
  },
  {
    id: 'deal-2',
    title: 'Free Large Fries',
    description: 'With any purchase of $10 or more. Exclusive app deal.',
    code: 'FREEFRIES',
    expiry: 'Ends in 12h',
    color: 'bg-mcd-red'
  },
  {
    id: 'deal-3',
    title: '$1 Any Size Coffee',
    description: 'Start your morning right with any size McCafé coffee.',
    code: 'COFFEE1',
    expiry: 'Daily Deal',
    color: 'bg-blue-500'
  }
];

export default function DealsPage() {
  return (
    <div className="min-h-screen pt-24 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <div className="inline-flex items-center gap-2 bg-mcd-red/10 border border-mcd-red/30 rounded-full px-4 py-1.5 mb-4">
            <Gift size={14} className="text-mcd-red" />
            <span className="text-[10px] font-mono uppercase tracking-widest text-mcd-red">Exclusive Offers</span>
          </div>
          <h1 className="font-display text-6xl mb-4 uppercase tracking-tight">Deals & Offers</h1>
          <p className="text-muted max-w-md">Personalized promotions just for you. Use these codes at checkout or in the app.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {DEALS.map((deal, idx) => (
            <motion.div
              key={deal.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              className="glass-card p-8 flex flex-col relative overflow-hidden group"
            >
              <div className={`absolute top-0 right-0 w-32 h-32 ${deal.color} opacity-10 blur-3xl -mr-10 -mt-10 group-hover:opacity-20 transition-opacity`} />
              
              <div className="flex justify-between items-start mb-6">
                <div className={`p-3 rounded-2xl ${deal.color} text-dark`}>
                  <Tag size={24} />
                </div>
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-muted uppercase tracking-wider bg-white/5 px-3 py-1 rounded-full">
                  <Clock size={12} />
                  {deal.expiry}
                </div>
              </div>

              <h3 className="text-2xl font-bold mb-3">{deal.title}</h3>
              <p className="text-muted text-sm mb-8 leading-relaxed flex-1">
                {deal.description}
              </p>

              <div className="space-y-4">
                <div className="bg-white/5 border border-dashed border-border p-4 rounded-xl flex justify-between items-center">
                  <span className="font-mono text-lg font-bold tracking-widest">{deal.code}</span>
                  <button className="text-gold text-xs font-bold uppercase tracking-widest hover:underline">Copy</button>
                </div>
                <button className="w-full bg-white text-dark py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-gold transition-colors">
                  Redeem Now
                  <ArrowRight size={18} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 glass-card p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 arch-gradient opacity-50" />
          <div className="relative z-10">
            <h2 className="font-display text-4xl mb-4 uppercase tracking-tight">Want more deals?</h2>
            <p className="text-muted mb-8 max-w-lg mx-auto">Download the MyMcDonald's app to unlock exclusive mobile-only offers and start earning rewards points on every order.</p>
            <div className="flex flex-wrap justify-center gap-4">
              <button className="bg-dark text-white px-8 py-4 rounded-xl font-bold border border-border hover:border-gold transition-colors">App Store</button>
              <button className="bg-dark text-white px-8 py-4 rounded-xl font-bold border border-border hover:border-gold transition-colors">Google Play</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
